
class InterpretedExpression:
    def eval(self,env):
        pass
