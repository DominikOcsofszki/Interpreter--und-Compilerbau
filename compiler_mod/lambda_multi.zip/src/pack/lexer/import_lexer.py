
tokens_import = ['import','as']

t_import = r'import'
# t_as = r'as'
