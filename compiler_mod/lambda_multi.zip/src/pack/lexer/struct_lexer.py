
# TODO: add extends
tokens_struct=['struct','extend']


t_struct='struct'
t_extend='extend'
