tokens_control = [
"LOOP",
"DO",
"FOR",
"IF",
"THEN",
"ELSE",
"WHILE",
        ]
