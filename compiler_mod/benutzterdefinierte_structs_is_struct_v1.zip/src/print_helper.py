import CONFIGS



def print_helpful(txt):
    if CONFIGS.HELP_PRINTS:
        print("[OPTIONAL] ",txt)
