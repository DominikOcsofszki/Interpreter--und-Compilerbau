Ablauf:

- typinferenz einfügen
- selbst def typen alla Standart ML
- Kein typsystem


verbindliche
- eigene definierte Datentype  -> Typsystem ist zu groß
- PythonModule importieren

Eigenes Produkt kann auch noch gebaut werden

===============================================

struct local :
    interne Vars werden abgespeichert

struct muss vom parent enf entfernt werden
- es müssen 2 ENVs erstellt werden.

- struct extends with dot private < reserved

- dict.__setitem__()


struct => Modulsystem mit with im kontext des structs

08.08, 22.08 => Donnerstage, eintrag auf WIKI

