tokens_var = ['ID','assign']
t_assign=r":="

literals_var =""


