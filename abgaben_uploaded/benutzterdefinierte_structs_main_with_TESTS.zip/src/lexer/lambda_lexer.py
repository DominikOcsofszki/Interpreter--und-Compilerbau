tokens_lambda = ['LAMBDA','LAMBDA_START']

# t_LAMBDA = r'->'
# t_LAMBDA_START = r'\\'
literals_komma=','

