literals_sequences = ';{}'
