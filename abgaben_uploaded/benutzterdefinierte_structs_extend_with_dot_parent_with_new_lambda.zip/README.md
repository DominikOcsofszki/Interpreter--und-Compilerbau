cd /Users/dominikocsofszki/ss2024/compiler/projekt/compiler_mod/
pwd
source .venv/bin/activate
cd src
pip install -e .
cd ..
python3 RUN.py
