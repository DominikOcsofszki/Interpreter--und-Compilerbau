tokens_import = ['IMPORT','AS']

t_IMPORT = r'IMPORT'
