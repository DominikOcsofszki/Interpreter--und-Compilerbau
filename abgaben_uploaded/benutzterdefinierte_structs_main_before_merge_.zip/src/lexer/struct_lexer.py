tokens_struct=['STRUCT','EXTEND']

t_STRUCT='struct'
t_EXTEND='extend'
