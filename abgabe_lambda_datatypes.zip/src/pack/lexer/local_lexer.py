# local assignment in expr

tokens_local = ['local','in']
# t_local=r'local'
# t_in=r'in'
